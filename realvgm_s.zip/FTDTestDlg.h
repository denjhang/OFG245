#pragma once
#include "afxwin.h"

#define FTDTEST_BF_MAX 0x10000

// CFTDTestDlg �_�C�A���O

class CFTDTestDlg : public CDialog
{
	DECLARE_DYNAMIC(CFTDTestDlg)

public:
	CFTDTestDlg(CWnd* pParent = NULL);   // �W���R���X�g���N�^
	virtual ~CFTDTestDlg();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_FTDTEST };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedDSend();
	afx_msg void OnBnClickedCSend();
	afx_msg void OnBnClickedSSend();
	CButton ddata7;
	CButton ddata6;
	CButton ddata5;
	CButton ddata4;
	CButton ddata3;
	CButton ddata2;
	CButton ddata1;
	CButton ddata0;
	CButton cdata7;
	CButton cdata6;
	CButton cdata5;
	CButton cdata4;
	CButton cdata3;
	CButton cdata2;
	CButton cdata1;
	CButton cdata0;
	CButton caddr3;
	CButton caddr2;
	CButton caddr1;
	CButton caddr0;
	CButton cbrdi;
	CButton cbrd3;
	CButton cbrd2;
	CButton cbrd1;
	CButton cbrd0;
	CEdit srate;
	CEdit sbyte;

	CEdit eoutput;
	unsigned char bf[FTDTEST_BF_MAX];

	void AddOutput(CString);
	void UpdateStatus();
	CEdit sloop;
	CButton cbrd5;
	CButton cbrda;
	CButton cbrdb;
	CComboBox cchipc;
	CComboBox cchipn;
	CStatic cstat;
	afx_msg void OnCbnSelchangeChipselc();
	afx_msg void OnCbnSelchangeChipseln();
	afx_msg void OnBnClickedCAddr3();
	afx_msg void OnBnClickedCAddr2();
	afx_msg void OnBnClickedCAddr1();
	afx_msg void OnBnClickedCAddr0();
	afx_msg void OnBnClickedCBrdI4();
	afx_msg void OnBnClickedCBrdI3();
	afx_msg void OnBnClickedCBrdI2();
	afx_msg void OnBnClickedCBrdI();
	afx_msg void OnBnClickedCBrd3();
	afx_msg void OnBnClickedCBrd2();
	afx_msg void OnBnClickedCBrd1();
	afx_msg void OnBnClickedCBrd0();
	afx_msg void OnBnClickedCData7();
	afx_msg void OnBnClickedCData6();
	afx_msg void OnBnClickedCData5();
	afx_msg void OnBnClickedCData4();
	afx_msg void OnBnClickedCData3();
	afx_msg void OnBnClickedCData2();
	afx_msg void OnBnClickedCData1();
	afx_msg void OnBnClickedCData0();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};

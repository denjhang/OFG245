// FTDTestDlg.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "RealVGM.h"
#include "FTDTestDlg.h"
#include "iface/rv_iface.h"
#include ".\ftdtestdlg.h"

// CFTDTestDlg �_�C�A���O

IMPLEMENT_DYNAMIC(CFTDTestDlg, CDialog)
CFTDTestDlg::CFTDTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFTDTestDlg::IDD, pParent)
{
}

CFTDTestDlg::~CFTDTestDlg()
{
}

void CFTDTestDlg::DoDataExchange(CDataExchange* pDX)
{
	int i;
	CString str;
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_D_DATA_7, ddata7);
	DDX_Control(pDX, IDC_D_DATA_6, ddata6);
	DDX_Control(pDX, IDC_D_DATA_5, ddata5);
	DDX_Control(pDX, IDC_D_DATA_4, ddata4);
	DDX_Control(pDX, IDC_D_DATA_3, ddata3);
	DDX_Control(pDX, IDC_D_DATA_2, ddata2);
	DDX_Control(pDX, IDC_D_DATA_1, ddata1);
	DDX_Control(pDX, IDC_D_DATA_0, ddata0);
	DDX_Control(pDX, IDC_C_DATA_7, cdata7);
	DDX_Control(pDX, IDC_C_DATA_6, cdata6);
	DDX_Control(pDX, IDC_C_DATA_5, cdata5);
	DDX_Control(pDX, IDC_C_DATA_4, cdata4);
	DDX_Control(pDX, IDC_C_DATA_3, cdata3);
	DDX_Control(pDX, IDC_C_DATA_2, cdata2);
	DDX_Control(pDX, IDC_C_DATA_1, cdata1);
	DDX_Control(pDX, IDC_C_DATA_0, cdata0);
	DDX_Control(pDX, IDC_C_ADDR_3, caddr3);
	DDX_Control(pDX, IDC_C_ADDR_2, caddr2);
	DDX_Control(pDX, IDC_C_ADDR_1, caddr1);
	DDX_Control(pDX, IDC_C_ADDR_0, caddr0);
	DDX_Control(pDX, IDC_C_BRD_I, cbrdi);
	DDX_Control(pDX, IDC_C_BRD_3, cbrd3);
	DDX_Control(pDX, IDC_C_BRD_2, cbrd2);
	DDX_Control(pDX, IDC_C_BRD_1, cbrd1);
	DDX_Control(pDX, IDC_C_BRD_0, cbrd0);
	DDX_Control(pDX, IDC_TEST_STATUS, eoutput);

	DDX_Control(pDX, IDC_S_RATE, srate);
	DDX_Control(pDX, IDC_S_BYTE, sbyte);
	DDX_Control(pDX, IDC_S_LOOP, sloop);
	DDX_Control(pDX, IDC_C_BRD_I2, cbrd5);
	DDX_Control(pDX, IDC_C_BRD_I3, cbrda);
	DDX_Control(pDX, IDC_C_BRD_I4, cbrdb);
	DDX_Control(pDX, IDC_CHIPSELC, cchipc);
	DDX_Control(pDX, IDC_CHIPSELN, cchipn);

	//�����ɏ���������
	eoutput.SetWindowText("[I/O Access Test]");
	for(i=0;i<DEVIF_MAX;i++){
		cchipc.AddString(DEVIF_ChipStr[i]);
	}
	for(i=0;i<MAX_SAMEDEVICES;i++){
		str.Format("%d",i);
		cchipn.AddString(str);
	}
	cchipc.SetCurSel(0);
	cchipn.SetCurSel(0);
	DDX_Control(pDX, IDC_CSTATUS, cstat);
}


BEGIN_MESSAGE_MAP(CFTDTestDlg, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDC_D_SEND, OnBnClickedDSend)
	ON_BN_CLICKED(IDC_C_SEND, OnBnClickedCSend)
	ON_BN_CLICKED(IDC_S_SEND, OnBnClickedSSend)
	ON_CBN_SELCHANGE(IDC_CHIPSELC, OnCbnSelchangeChipselc)
	ON_CBN_SELCHANGE(IDC_CHIPSELN, OnCbnSelchangeChipseln)
	ON_BN_CLICKED(IDC_C_ADDR_3, OnBnClickedCAddr3)
	ON_BN_CLICKED(IDC_C_ADDR_2, OnBnClickedCAddr2)
	ON_BN_CLICKED(IDC_C_ADDR_1, OnBnClickedCAddr1)
	ON_BN_CLICKED(IDC_C_ADDR_0, OnBnClickedCAddr0)
	ON_BN_CLICKED(IDC_C_BRD_I4, OnBnClickedCBrdI4)
	ON_BN_CLICKED(IDC_C_BRD_I3, OnBnClickedCBrdI3)
	ON_BN_CLICKED(IDC_C_BRD_I2, OnBnClickedCBrdI2)
	ON_BN_CLICKED(IDC_C_BRD_I, OnBnClickedCBrdI)
	ON_BN_CLICKED(IDC_C_BRD_3, OnBnClickedCBrd3)
	ON_BN_CLICKED(IDC_C_BRD_2, OnBnClickedCBrd2)
	ON_BN_CLICKED(IDC_C_BRD_1, OnBnClickedCBrd1)
	ON_BN_CLICKED(IDC_C_BRD_0, OnBnClickedCBrd0)
	ON_BN_CLICKED(IDC_C_DATA_7, OnBnClickedCData7)
	ON_BN_CLICKED(IDC_C_DATA_6, OnBnClickedCData6)
	ON_BN_CLICKED(IDC_C_DATA_5, OnBnClickedCData5)
	ON_BN_CLICKED(IDC_C_DATA_4, OnBnClickedCData4)
	ON_BN_CLICKED(IDC_C_DATA_3, OnBnClickedCData3)
	ON_BN_CLICKED(IDC_C_DATA_2, OnBnClickedCData2)
	ON_BN_CLICKED(IDC_C_DATA_1, OnBnClickedCData1)
	ON_BN_CLICKED(IDC_C_DATA_0, OnBnClickedCData0)
//	ON_WM_KEYDOWN()
END_MESSAGE_MAP()


void CFTDTestDlg::AddOutput(CString str){
	CString sbf;
	eoutput.SetSel(eoutput.GetLimitText(), eoutput.GetLimitText(), 0 );
	eoutput.ReplaceSel("\r\n" + str);
}

void CFTDTestDlg::UpdateStatus(){
	CString sbf;
	
	Uint8 d = cchipc.GetCurSel();
	Uint8 n = cchipn.GetCurSel();
	Uint8 a = 
	   (cbrdb.GetCheck() << 7)
	 | (cbrda.GetCheck() << 6)
	 | (cbrd5.GetCheck() << 5)
	 | (cbrdi.GetCheck() << 4)
	 | (cbrd3.GetCheck() << 3)
	 | (cbrd2.GetCheck() << 2)
	 | (cbrd1.GetCheck() << 1)
	 | (cbrd0.GetCheck() << 0);
	Uint8 p =
	   (caddr3.GetCheck() << 3)
	 | (caddr2.GetCheck() << 2)
	 | (caddr1.GetCheck() << 1)
	 | (caddr0.GetCheck() << 0);
	Uint8 v = 
	   (cdata7.GetCheck() << 7)
	 | (cdata6.GetCheck() << 6)
	 | (cdata5.GetCheck() << 5)
	 | (cdata4.GetCheck() << 4)
	 | (cdata3.GetCheck() << 3)
	 | (cdata2.GetCheck() << 2)
	 | (cdata1.GetCheck() << 1)
	 | (cdata0.GetCheck() << 0);

	sbf.Format("[%s.%02d] P.%02X A.%02X V.%02X", DEVIF_ChipStr[d], n, p, a, v);
	cstat.SetWindowText(sbf);
}
// CFTDTestDlg ���b�Z�[�W �n���h��

void CFTDTestDlg::OnBnClickedOk()
{
	// TODO : �����ɃR���g���[���ʒm�n���h�� �R�[�h��ǉ����܂��B
	//OnOK();
}

void CFTDTestDlg::OnBnClickedDSend()
{
	//FTD���C�g
	CString sbf;
	char ret;
	Uint8 v = 
	   (ddata7.GetCheck() << 7)
	 | (ddata6.GetCheck() << 6)
	 | (ddata5.GetCheck() << 5)
	 | (ddata4.GetCheck() << 4)
	 | (ddata3.GetCheck() << 3)
	 | (ddata2.GetCheck() << 2)
	 | (ddata1.GetCheck() << 1)
	 | (ddata0.GetCheck() << 0);

	//ret = FTDWrite1(v);
	//sbf.Format("Write - %02X  %s", v, ret?"x":"OK");
	//AddOutput(sbf);
}

void CFTDTestDlg::OnBnClickedCSend()
{
	//�������C�g
	CString sbf;
	
	Uint8 d = cchipc.GetCurSel();
	Uint8 n = cchipn.GetCurSel();
	Uint8 a = 
	   (cbrdb.GetCheck() << 7)
	 | (cbrda.GetCheck() << 6)
	 | (cbrd5.GetCheck() << 5)
	 | (cbrdi.GetCheck() << 4)
	 | (cbrd3.GetCheck() << 3)
	 | (cbrd2.GetCheck() << 2)
	 | (cbrd1.GetCheck() << 1)
	 | (cbrd0.GetCheck() << 0);
	Uint8 p =
	   (caddr3.GetCheck() << 3)
	 | (caddr2.GetCheck() << 2)
	 | (caddr1.GetCheck() << 1)
	 | (caddr0.GetCheck() << 0);
	Uint8 v = 
	   (cdata7.GetCheck() << 7)
	 | (cdata6.GetCheck() << 6)
	 | (cdata5.GetCheck() << 5)
	 | (cdata4.GetCheck() << 4)
	 | (cdata3.GetCheck() << 3)
	 | (cdata2.GetCheck() << 2)
	 | (cdata1.GetCheck() << 1)
	 | (cdata0.GetCheck() << 0);

	rvs_push(d, n, p, a, v);
	rvs_send();
	sbf.Format("[%s.%02d] P.%02X A.%02X V.%02X", DEVIF_ChipStr[d], n, p, a, v);
	AddOutput(sbf);
}

void CFTDTestDlg::OnBnClickedSSend()
{
	CString sbf;
	Uint32 byte;
	Uint32 rate;
	Uint32 loop,a,b,c;
	Uint32 cst,ced;
	
	srate.GetWindowText(sbf);
	rate = _tstoi(sbf);
	sbyte.GetWindowText(sbf);
	byte = _tstoi(sbf);
	sloop.GetWindowText(sbf);
	loop = _tstoi(sbf);
	if(byte > FTDTEST_BF_MAX) byte = FTDTEST_BF_MAX;
	if(loop < 1) loop = 1;

	//sbf.Format("SpdTest - R:%d B:%d x%d",rate,byte,loop);
	//AddOutput(sbf);

	for(a=0,b=0;a<byte-1;a++,b++){
		bf[a] = ((b>>7)&0x7f) | 0x80;
	}
	bf[byte-1] = 0xbf;

	//FTDOpen(0,rate);
	cst = clock();
	for(a=0;a<loop;a++){
		//FTDWrite(bf,byte);
	}
	ced = clock();
	//FTDOpen(0,0);
	//sbf.Format("       Time:%d",ced-cst);
	//AddOutput(sbf);

}



void CFTDTestDlg::OnCbnSelchangeChipselc()
{
	UpdateStatus();
}

void CFTDTestDlg::OnCbnSelchangeChipseln()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCAddr3()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCAddr2()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCAddr1()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCAddr0()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrdI4()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrdI3()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrdI2()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrdI()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrd3()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrd2()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrd1()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCBrd0()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData7()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData6()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData5()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData4()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData3()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData2()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData1()
{
	UpdateStatus();
}

void CFTDTestDlg::OnBnClickedCData0()
{
	UpdateStatus();
}

BOOL CFTDTestDlg::PreTranslateMessage(MSG* pMsg)
{
	// TODO : �����ɓ���ȃR�[�h��ǉ����邩�A�������͊�{�N���X���Ăяo���Ă��������B
	if(pMsg->message == WM_KEYDOWN){
		if(pMsg->wParam == 13){
			OnBnClickedCSend();
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}

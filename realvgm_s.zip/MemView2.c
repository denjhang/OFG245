#include <windows.h>
#include <stdio.h>

#include "MemView2.h"

#define MEM_MAX 0xffff //���ǂ����S��FFFFH


LRESULT CALLBACK MemView2Proc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	int mempos=0;
	char strbuffer[256];
	int loop=0;

	return TRUE;
	/*
	switch(message)
	{
	case WM_INITDIALOG :
		SendMessage(hDlg,WM_COMMAND,IDC_SPEED3,0);
		CheckRadioButton(hDlg,IDC_SPEED1,IDC_SPEED5,IDC_SPEED3);
		mempos=0;
		SetScrollPos(GetDlgItem(hDlg,IDC_MEMSCR),SB_CTL,0,TRUE);
	case WM_INITDIALOG|0x8000 :
		SetScrollRange(GetDlgItem(hDlg,IDC_MEMSCR),SB_CTL,0,(MEM_MAX-0xff)/0x10,TRUE);
		if(memview_memread==NULL){
			return TRUE;
		}
		return TRUE;

	case WM_TIMER :
		mempos=GetScrollPos(GetDlgItem(hDlg,IDC_MEMSCR),SB_CTL)<<4;
		if(memview_memread==NULL){
			for(loop=0;loop<16;loop++){
				sprintf(strbuffer,"%04X|                                                  ",mempos + loop*16);
				SetWindowText(GetDlgItem(hDlg,memview_idc[loop]),strbuffer);
			}
//			SetScrollRange(GetDlgItem(hDlg,IDC_MEMSCR),SB_CTL,-1,-1,TRUE);
//			SetScrollPos(GetDlgItem(hDlg,IDC_MEMSCR),SB_CTL,-1,TRUE);
			return TRUE;
		}

		sprintf(strbuffer,"");
		for(loop=0;loop<16;loop++){
			sprintf(strbuffer,"%04X| %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X %02X   \r\n"
				,mempos + loop*16
				,memview_memread!=NULL ? memview_memread(mempos + 0x0 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x1 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x2 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x3 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x4 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x5 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x6 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x7 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x8 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0x9 + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0xa + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0xb + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0xc + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0xd + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0xe + loop*16) : 0
				,memview_memread!=NULL ? memview_memread(mempos + 0xf + loop*16) : 0
			);
			SetWindowText(GetDlgItem(hDlg,memview_idc[loop]),strbuffer);
			sprintf(strbuffer,"");
		}

		return TRUE;

	case WM_COMMAND :
		if (LOWORD(wParam) == IDCANCEL){
			KillTimer(hDlg,0);
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_SPEED1){
			KillTimer(hDlg,0);
			SendMessage(hDlg,WM_TIMER,0,0);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_SPEED2){
			SetTimer(hDlg,0,200,0);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_SPEED3){
			SetTimer(hDlg,0,100,0);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_SPEED4){
			SetTimer(hDlg,0,50,0);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_SPEED5){
			SetTimer(hDlg,0,0,0);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_ADR_IO){
			SendMessage(hDlg,WM_VSCROLL,LOWORD(wParam|0x8000),0);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_ADR_RAM){
			SendMessage(hDlg,WM_VSCROLL,LOWORD(wParam|0x8000),0);
			return TRUE;
		}
		if (LOWORD(wParam) == IDC_ADR_ROM){
			SendMessage(hDlg,WM_VSCROLL,LOWORD(wParam|0x8000),0);
			return TRUE;
		}
		break;

    case WM_VSCROLL:
		{
			int nScrollCode = (int) LOWORD(wParam);
			int nPos = (int)(short int) HIWORD(wParam);
			mempos=GetScrollPos(GetDlgItem(hDlg,IDC_MEMSCR),SB_CTL)<<4;

			switch(nScrollCode){
				case SB_LINEDOWN:		//1�s���փX�N���[��
					nPos = (mempos>>4) + 1;
					break;
				case SB_LINEUP:			//1�s��փX�N���[��
					nPos = (mempos>>4) - 1;
					break;
				case SB_PAGEDOWN:		//1�y�[�W���փX�N���[��
					nPos = (mempos>>4) + 16;
					break;
				case SB_PAGEUP:			//1�y�[�W��փX�N���[��
					nPos = (mempos>>4) - 16;
					break;
				case SB_BOTTOM:			//��ԉ��܂ŃX�N���[��
					nPos = (MEM_MAX>>4)-0xf;
					break;
				case SB_TOP:			//��ԏ�܂ŃX�N���[��
					nPos = 0;
					break;
				case SB_THUMBPOSITION:	//��Έʒu�փX�N���[��
				case SB_THUMBTRACK:
					break;
				case IDC_ADR_IO|0x8000:		//�A�h���X�w��{�^���iIO�j
					nPos = MEM_IO>>4;
					break;
				case IDC_ADR_RAM|0x8000:		//�A�h���X�w��{�^���iRAM�j
					nPos = MEM_RAM>>4;
					break;
				case IDC_ADR_ROM|0x8000:		//�A�h���X�w��{�^���iROM�j
					nPos = MEM_ROM>>4;
					break;
				case SB_ENDSCROLL:		//�X�N���[���I��
				default:
					return TRUE;
			}
			if(nPos < 0) nPos=0;
			if(nPos > (MEM_MAX>>4)-0xf) nPos=(MEM_MAX>>4)-0xf;
			SetScrollPos(GetDlgItem(hDlg,IDC_MEMSCR),SB_CTL,nPos,TRUE);
			mempos = nPos<<4;
			SendMessage(hDlg,WM_TIMER,0,0);
		}	
		return TRUE;
	}
	return FALSE;
	*/
}


void CreateMemView2(HINSTANCE hDllInstance, HWND hwndParent)
{
	WNDCLASSEX wcl;

	wcl.cbSize        = sizeof(wcl);        /* �\���̂̑傫�� */
	wcl.style         = 0; /* �X�^�C�� */
	wcl.lpfnWndProc   = MemView2Proc;
	wcl.cbClsExtra    = 0;
	wcl.cbWndExtra    = 0;
	wcl.hInstance     = hDllInstance;
	wcl.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
	wcl.hCursor       = LoadCursor(NULL, IDC_ARROW);
	wcl.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wcl.lpszMenuName  = NULL;
	wcl.lpszClassName = "MemView2";
	wcl.hIconSm       = LoadIcon (NULL, IDI_APPLICATION);

	RegisterClassEx(&wcl); /* �E�C���h�E�N���XTest Window��o�^ */

	ShowWindow(
		CreateDialog(hDllInstance, "MemView2", "Memory Viewer", MemView2Proc)
		,SW_SHOW
	);
}


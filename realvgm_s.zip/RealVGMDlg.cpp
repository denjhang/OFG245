// RealVGMDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RealVGM.h"
#include "RealVGMDlg.h"
#include ".\realvgmdlg.h"
#include "FTDTestDlg.h"
#include "MemView2.h"
#include "iface/rv_util.h"

#include <mmsystem.h>
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CRealVGMDlg dialog



CRealVGMDlg::CRealVGMDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRealVGMDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRealVGMDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_MSG, cmsg);
	DDX_Control(pDX, IDC_STATUS_UNDER, custatus);
	DDX_Control(pDX, IDC_SEL_RELOAD, cselreload);
	DDX_Control(pDX, IDC_MUSICNUM, cmusicnum);
	DDX_Control(pDX, IDC_SPIN1, cmusicnum_spin);
	DDX_Control(pDX, IDC_SEL_NONRESET, cselnonreset);
}

BEGIN_MESSAGE_MAP(CRealVGMDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
	ON_COMMAND(ID_SETUP_CONTROLTEST, OnSetupControltest)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_PLAY, OnBnClickedBplay)
	ON_COMMAND(ID_FILE_STOP, OnBnClickedBstop)
	ON_COMMAND(ID_FILE_PAUSE, OnBnClickedBpause)
	ON_COMMAND(ID_FILE_EXIT, OnBnClickedCancel)
	ON_BN_CLICKED(IDC_BOPEN, OnBnClickedBopen)
	ON_WM_CLOSE()
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BPLAY, OnBnClickedBplay)
	ON_BN_CLICKED(IDC_BSTOP, OnBnClickedBstop)
	ON_BN_CLICKED(IDC_BPAUSE, OnBnClickedBpause)
ON_BN_CLICKED(IDC_BSETUP, OnBnClickedBsetup)
ON_COMMAND(IDM_ABOUTBOX, OnAboutbox)
ON_WM_DROPFILES()
END_MESSAGE_MAP()


// CRealVGMDlg message handlers

BOOL CRealVGMDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	/*
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	*/
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	//IF������
	rvs_ifopen();
	cmsg.SetWindowText(if_sstr);

	//�Ȕԍ��I������
	memset(&dec,0,sizeof(DECODE_INTERFACE));
	status = -1;
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRealVGMDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CRealVGMDlg::OnAboutbox()
{
	// TODO : �����ɃR�}���h �n���h�� �R�[�h��ǉ����܂��B
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRealVGMDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRealVGMDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CRealVGMDlg::OnBnClickedOk()
{
	// TODO : �����ɃR���g���[���ʒm�n���h�� �R�[�h��ǉ����܂��B
	//OnOK();
}

void CRealVGMDlg::OnBnClickedCancel()
{
	// TODO : �����ɃR���g���[���ʒm�n���h�� �R�[�h��ǉ����܂��B
	OnCancel();
}

void CRealVGMDlg::OnSetupControltest()
{
	// TODO : �����ɃR�}���h �n���h�� �R�[�h��ǉ����܂��B
	CFTDTestDlg dlg;
	dlg.DoModal();
}


void CRealVGMDlg::OnFileOpen()
{
	CFileDialog fd(TRUE, NULL,
                    "*.*",
                    OFN_HIDEREADONLY,
                    "All Files(*.*)|*.*|Supported Files|*.vgm;*.osg|VGM File(*.vgm)|*.vgm|OSGS File(*.osg)|*.osg||",
                    this);
	if(fd.DoModal()==IDOK){
		char str[512];
		OnBnClickedBstop();
		strcpy(str,(LPCTSTR)fd.GetPathName());
		if(rvd_open(&dec,str)){
			d_info(&dec,1,str);
			cmsg.SetWindowText((LPCTSTR)str);
			cmusicnum_spin.SetRange(0,d_info(&dec,2,0));
			cmusicnum.SetWindowText("0");
			strcpy(filepath,(LPCTSTR)fd.GetPathName());
			status = 0;
		}else{
			cmsg.SetWindowText("File Open Failed.\r\n("+fd.GetPathName()+")");
		}
	}
}

void CRealVGMDlg::OnBnClickedBopen()
{
	// TODO : �����ɃR���g���[���ʒm�n���h�� �R�[�h��ǉ����܂��B
	OnFileOpen();
}

void CRealVGMDlg::OnClose()
{
	CDialog::OnClose();
}

void CRealVGMDlg::OnCancel()
{
	OnBnClickedBstop();
	d_close(&dec);
	rvs_ifclose();
	CDialog::OnCancel();
}

DWORD WINAPI CRealVGMDlg::Thread1(LPVOID lpV){
	CRealVGMDlg *thre = (CRealVGMDlg*)lpV;
	thre->threadFuncHR();
	return 0;
}

#define TIME_DEP 1000.0

// �}���`���f�B�A�^�C�}�[�ɂ�銄�荞�݃Q�[�g
void CALLBACK CRealVGMDlg::TimeProc1(UINT uID, UINT uMsg, DWORD_PTR dwUser, DWORD dw1, DWORD dw2){
	SetEvent((HANDLE)dwUser);
}

void CRealVGMDlg::threadFuncHR(void){
	LARGE_INTEGER fq, bef, aft;
	volatile double tim,timb,timd;
	HANDLE evt;
	MMRESULT mmr;
	//�����x�N���b�N�ϐ��̏�����
	memset(&fq,  0, sizeof fq );
	memset(&bef, 0, sizeof bef);
	memset(&aft, 0, sizeof aft);

	QueryPerformanceFrequency(&fq);
	QueryPerformanceCounter(&bef);	
	QueryPerformanceCounter(&aft);

	//�E�F�C�g�p�C�x���g�̏�����
	evt = CreateEvent(NULL,FALSE,FALSE,NULL);
	timeBeginPeriod(1);
	mmr = timeSetEvent(1,1,(LPTIMECALLBACK)TimeProc1,(DWORD)evt,TIME_PERIODIC);

	timb = tim = 0.0;
	while(status&3){
		if(status&2){
			tim = timb = d_drive(&dec,(timb - tim) / TIME_DEP) * TIME_DEP;
			if(tim < 0){
				//�Đ����I����Ă���X���b�h���I���
				timeKillEvent(mmr);
				status = 0;
				return;
			}
			//�Z���ꍇ�́A�͋Ƃő҂��܂��B
			do{
				if(tim > 0 * TIME_DEP){
					//���̃E�F�C�g�������ꍇ�ACPU�p���[��H��Ȃ����@�ő҂��܂��傤
					WaitForSingleObject(evt,INFINITE);
				}
				QueryPerformanceCounter(&aft);
				timd = ((aft.QuadPart - bef.QuadPart) * 1000.0 * TIME_DEP / fq.QuadPart);
				if(timd >= 1){
					tim -= timd;
					bef = aft;
				}
			} while(tim > 3.0 * TIME_DEP && status==3);
		}else{
			//PAUSE���Ă�ꍇ
			QueryPerformanceCounter(&aft);
			bef = aft;
			Sleep(16);//Sleep�֐��ŃE�F�C�g������
		}
	}
	timeKillEvent(mmr);
	status = 0;
}

void CRealVGMDlg::OnTimer(UINT nIDEvent)
{
	char str[100];
	switch(status){
	case 0://STOP
		KillTimer(1);
		strcpy(str,"[STOP]");
		custatus.SetWindowText(str);
		break;
	case 1://PAUSE
		strcpy(str,"@ ");
		d_info(&dec,10,str+2);
		custatus.SetWindowText(str);
		break;
	case 3://PLAY
		strcpy(str,"> ");
		d_info(&dec,10,str+2);
		custatus.SetWindowText(str);
		break;
	}

	CDialog::OnTimer(nIDEvent);
}


void CRealVGMDlg::OnBnClickedBplay()
{
	DWORD threid;
	CString bf;
	switch(status){
	case 1://PAUSE
	case 3://PLAY
		if(!cselnonreset.GetCheck()){
			OnBnClickedBstop();
		}else{
			//status = 4;//�X���b�h�I���҂�
			//while(status==4)Sleep(16);//0�ɂȂ�܂ő҂�
		}
	case 0://STOP
		//�Đ��O�ɁA�����[�h�t���O�������Ă���ꍇ�́A�����[�h����
		if(cselreload.GetCheck()){
			char str[512];
			d_close(&dec);
			if(!rvd_open(&dec,filepath)){
				custatus.SetWindowText("File Reload Error");
				break;
			}
			d_info(&dec,1,str);
			cmsg.SetWindowText((LPCTSTR)str);
			cmusicnum_spin.SetRange(0,d_info(&dec,2,0));
		}
		//�Đ���Ԃ����
		cmusicnum.GetWindowText(bf);
		d_start(&dec,atoi(bf));
		KillTimer(1);
		SetTimer(1,50,0);

		//�h���C�o�Ԃ�񂵗p�X���b�h�����
		if(status==0){
			hthre = CreateThread(NULL,1024 * 16,&CRealVGMDlg::Thread1,(LPVOID)this,NULL,&threid);
			SetPriorityClass(hthre, HIGH_PRIORITY_CLASS);
		}
		status = 3;//PLAY�ɂ���
		break;
	}
}

void CRealVGMDlg::OnBnClickedBstop()
{
	switch(status){
	case 3://PLAY
	case 1://PAUSE
		status = 4;//�X���b�h�I���҂�
		while(status==4)Sleep(16);//0�ɂȂ�܂ő҂�
		d_stop(&dec);
		break;
	}
}

void CRealVGMDlg::OnBnClickedBpause()
{
	switch(status){
	case 3:
		//3:PLAY
		status = 1;//PAUSE�ɂ���
		break;
	case 1:
		//1:PAUSE
		status = 3;//PLAY�ɂ���
		break;
	}
}


void CRealVGMDlg::OnBnClickedBsetup()
{
	// TODO : �����ɃR���g���[���ʒm�n���h�� �R�[�h��ǉ����܂��B
}



void CRealVGMDlg::OnDropFiles(HDROP hDropInfo)
{
	char str[512];
	CString strbf;
	OnBnClickedBstop();
	//�h���b�v���ꂽ�t�@�C���p�X���擾
	DragQueryFile(hDropInfo, 0, str, 512);
	if(rvd_open(&dec,str)){
		strcpy(filepath,str);
		d_info(&dec,1,str);
		cmsg.SetWindowText((LPCTSTR)str);
		cmusicnum_spin.SetRange(0,d_info(&dec,2,0));
		cmusicnum.SetWindowText("0");
		status = 0;
	}else{
		strbf.Format("File Open Failed.\r\n(%s)", str);
		cmsg.SetWindowText(strbf);
	}
	
	CDialog::OnDropFiles(hDropInfo);
}

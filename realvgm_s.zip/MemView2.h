#ifdef __cplusplus
extern "C" {
#endif

void CreateMemView2(HINSTANCE hDllInstance, HWND hwndParent);

#ifdef __cplusplus
}
#endif
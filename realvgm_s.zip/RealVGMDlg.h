// RealVGMDlg.h : header file
//

#pragma once
#include "afxwin.h"
#include "afxcmn.h"


// CRealVGMDlg dialog
class CRealVGMDlg : public CDialog
{
// Construction
public:
	CRealVGMDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_REALVGM_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnSetupControltest();
	afx_msg void OnFileOpen();
	CEdit cmsg;
	afx_msg void OnBnClickedBopen();
	afx_msg void OnClose();

private:
	DECODE_INTERFACE dec;
	DWORD btime;
	char status;//0:STOP 3:PLAY 1:PAUSE
	HANDLE hthre;
	static DWORD WINAPI CRealVGMDlg::Thread1(LPVOID);
	void CRealVGMDlg::threadFuncHR(void);
	static void CALLBACK CRealVGMDlg::TimeProc1(UINT uID, UINT uMsg, DWORD_PTR dwUser, DWORD dw1, DWORD dw2);

public:
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnBnClickedBplay();
	afx_msg void OnBnClickedBstop();
	afx_msg void OnBnClickedBpause();
	CStatic custatus;
	afx_msg void OnBnClickedBsetup();
protected:
	virtual void OnCancel();
public:
	afx_msg void OnAboutbox();
	CButton cselreload;
	CEdit cmusicnum;
	CSpinButtonCtrl cmusicnum_spin;
	char filepath[500];//�����[�h�p
	CButton cselnonreset;
	afx_msg void OnDropFiles(HDROP hDropInfo);
};

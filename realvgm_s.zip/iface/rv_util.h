#ifndef __RV_UTIL__
#define __RV_UTIL__ 1

#ifndef Int
typedef int				Int;
typedef unsigned int	Uint;
typedef signed int		Int32;
typedef signed long		Int64;
typedef unsigned long	Uint64;
typedef signed short	Int16;
typedef unsigned short	Uint16;
typedef signed char		Int8;
typedef char			Char;
typedef double			Double;
#endif

#ifndef Uint32
#define Uint32 unsigned int
#endif
#ifndef Uint8
#define Uint8 unsigned char
#endif


//���p�Ŏg�����̂Ƃ�
#define	IFINI_NAME	"interface"
#define	APP_NAME	"RealVGM"

#ifdef __cplusplus
extern "C" {
#endif

/* ---------- �ݒ�t�@�C���ǂݍ��ݕ��� ------------------------------
*/

//�f�B���N�g���̋�؂蕶�����`����BOS������Ă����v�Ȃ悤��
#ifdef _WIN32
	#define DIRSEP "\\"
#else
	#define DIRSEP "/"
#endif

#define INIFILE_MAXSIZE 32768

//�����Ȃ珟��ɒǉ�
#ifndef MAX_PATH
	#define MAX_PATH 260
#endif

typedef struct{
	Uint8 inidat[INIFILE_MAXSIZE];
	Uint32 inisize;
	Char inipath[MAX_PATH];
	Uint8 inichangefg;
}INIFILE;

extern Char curdir[MAX_PATH];
void WritePrivateProfileInt(char* lpAppName, char* lpKeyName, int value, char* lpFileName );
Uint8 GetWritePrivateProfileInt(char* lpAppName, char* lpKeyName, int value, char* lpFileName );

INIFILE* NewIniFile(Char* file);
INIFILE* OpenIniFile(Char* file);
Uint8 CloseIniFile(INIFILE* ifi);
Uint8 WriteIniFile(INIFILE* ifi);
Int32 ReadIniVal(INIFILE* ifi, const Char* group, const Char* param, Uint32 strmax, Char* strbf);
Int32 WriteIniVal(INIFILE* ifi, const Char* group, const Char* param, Uint32 val, Char* str);
Int32 ReadWriteIniVal(INIFILE* ifi, const Char* group, const Char* param, Uint32 val);
Int32 ReadWriteIniString(INIFILE* ifi, const Char* group, const Char* param, Uint32 slen, Char* str);

#ifdef __cplusplus
}
#endif


#endif //__RV_UTIL__


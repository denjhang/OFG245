#include "rv_iface.h"
#include "s_ofg245.h"

#include "d_vgm.h"
#include "d_osgs.h"

#include <windows.h>

SEND_INTERFACE rv_sendif[SENDIF_MAX];
//DECODE_INTERFACE rv_decodeif[DECODEIF_MAX];
Uint8 sifmax = 0;

Char if_sstr[IF_SSTR_MAX];

void rvs_ifopen(){
	Char* inifile[MAX_PATH];
	Uint8 i,im;
	INIFILE *ifi;

	if_sstr[0] = 0;

	//�ݒ�ǂݍ���
	strcpy(inifile, curdir);
	strcat(inifile,DIRSEP APP_NAME ".ini");
	sifmax = 0;

	ifi = OpenIniFile(inifile);

	//OFG245��
	im = ReadWriteIniVal(ifi, "Interface", "OFG245", 0);
	strcat(if_sstr,"[OFG245]\r\n");
	for(i=0;i<im;i++){
		s_ofg245_new(&rv_sendif[sifmax]);
		if(s_open(&rv_sendif[sifmax],i)){
			//�����ς�
			strcat(if_sstr,"x");
			s_close(&rv_sendif[sifmax]);
		}else{
			//��������
			strcat(if_sstr,"O");
			sifmax++;
		}
	}

	//RE1��
	im = ReadWriteIniVal(ifi, "Interface", "RE1", 0);
	strcat(if_sstr,"\r\n[RE1]\r\n");
	for(i=0;i<im;i++){
		s_re1_new(&rv_sendif[sifmax]);
		if(s_open(&rv_sendif[sifmax],i)){
			//�����ς�
			strcat(if_sstr,"x");
			s_close(&rv_sendif[sifmax]);
		}else{
			//��������
			strcat(if_sstr,"O");
			sifmax++;
		}
	}
	CloseIniFile(ifi);
}

void rvs_ifclose(){
	Uint8 i;
	for(i=0;i<sifmax;i++){
		s_close(&rv_sendif[i]);
	}
}

void rvs_reset(){
	Uint8 i;
	for(i=0;i<sifmax;i++){
		s_reset(&rv_sendif[i]);
	}
}

void rvs_push(Uint8 chip, Uint8 num, Uint8 abus, Uint8 addr, Uint8 val){
	Uint8 i;
	for(i=0;i<sifmax;i++){
		s_push(&rv_sendif[i], chip, num, abus, addr, val);
	}
}

void rvs_send(){
	Uint8 i;
	for(i=0;i<sifmax;i++){
		s_send(&rv_sendif[i]);
	}
}

Uint32 rvs_info(Uint8 num, Char* strp){
	if(num < sifmax){
		s_info(&rv_sendif[num], strp);
		return 0;
	}
	return 1;
}

//�t�@�C�����J���B
//0:�~�X 1:VGM 2:OSGS
Uint8 rvd_open(DECODE_INTERFACE *dec, Char *path){
	d_vgm_new(dec);
	if(!d_open(dec,path))return 1;
	dec->close();
	d_osgs_new(dec);
	if(!d_open(dec,path))return 2;
	dec->close();
	return 0;
}

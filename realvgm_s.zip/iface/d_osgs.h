#include "rv_iface.h"


#ifdef __cplusplus
extern "C" {
#endif

Uint8 d_osgs_new(DECODE_INTERFACE *i);

#ifdef __cplusplus
}
#endif

#include "rv_iface.h"

//


#ifdef __cplusplus
extern "C" {
#endif

Int32 FTDSearchSN2Dev(Char* ssn);
Uint8 FTDOpen(void* obj, Uint32 num, Uint32 spd);
void FTDClose(void* obj);
Uint8 FTDWrite(void* obj, Uint8 *data, Uint32 bytes);
Uint8 FTDWrite1(void* obj, Uint8 data);
Uint8 FTVReset();

Uint8 s_re1_new(SEND_INTERFACE *i);

#ifdef __cplusplus
}
#endif


//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RealVGM.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REALVGM_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDD_FTDTEST                     131
#define IDD_PLAYERSET                   132
#define IDC_BOPEN                       1000
#define IDC_BPLAY                       1001
#define IDC_BSTOP                       1002
#define IDC_BPAUSE                      1003
#define IDC_BSETUP                      1004
#define IDC_SSEEK                       1006
#define IDC_MSG                         1007
#define IDC_C_DATA_7                    1008
#define IDC_TEST_STATUS                 1010
#define IDC_S_RATE                      1011
#define IDC_C_DATA_6                    1012
#define IDC_C_DATA_5                    1013
#define IDC_C_DATA_4                    1014
#define IDC_C_DATA_3                    1015
#define IDC_C_DATA_2                    1016
#define IDC_C_DATA_1                    1017
#define IDC_C_DATA_0                    1018
#define IDC_C_ADDR_3                    1019
#define IDC_C_ADDR_2                    1020
#define IDC_C_ADDR_1                    1021
#define IDC_C_ADDR_0                    1022
#define IDC_C_BRD_I                     1023
#define IDC_C_BRD_3                     1024
#define IDC_C_BRD_2                     1025
#define IDC_C_BRD_1                     1026
#define IDC_C_BRD_0                     1027
#define IDC_D_DATA_7                    1028
#define IDC_D_DATA_6                    1029
#define IDC_D_DATA_5                    1030
#define IDC_D_DATA_4                    1031
#define IDC_D_DATA_3                    1032
#define IDC_D_DATA_2                    1033
#define IDC_D_DATA_1                    1034
#define IDC_D_DATA_0                    1035
#define IDC_D_SEND                      1036
#define IDC_C_SEND                      1037
#define IDC_S_BYTE                      1038
#define IDC_S_SEND                      1039
#define IDC_S_LOOP                      1040
#define IDC_C_BRD_I2                    1041
#define IDC_C_BRD_I3                    1042
#define IDC_C_BRD_I4                    1043
#define IDC_CHIPSELC                    1044
#define IDC_CHIPSELN                    1045
#define IDC_CSTATUS                     1046
#define IDC_STATUS_UNDER                1048
#define IDC_MUSICNUM                    1051
#define IDC_SPIN1                       1052
#define IDC_SEL_RELOAD                  1053
#define IDC_SEL_RELOAD2                 1054
#define IDC_SEL_NONRESET                1054
#define ID_FILE_PLAY                    32772
#define ID_FILE_STOP                    32773
#define ID_FILE_PAUSE                   32775
#define ID_FILE_EXIT                    32776
#define ID_SETUP_SLOT                   32777
#define ID_SETUP_PLAYERSETTING          32778
#define ID_SETUP_CONTROLTEST            32779
#define ID_DEVICE                       32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
